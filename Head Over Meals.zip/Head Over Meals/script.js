function enterSite() {
    console.log("enter");
    $("#start").css("transform", "translate(-200vw)");
    $("#dim-start").css("transform", "translate(0)");
    $("#dim-start").css("visibility","visible");
    $("#site").css("visibility", "visible");
    $("#site").css("overflow-y", "visible");
    $("#site").css("max-height", "auto");
    $("#content").css("opacity", "1");
    $("#register-side-bar").css("transform", "translate(0)");
}

$("#form").mouseleave(function() {closeForm();})

function openForm() {
    console.log("login");
    $("#form").css("transform", "translate(0)");
}
function closeForm() {
    $("#form").css("transform", "translate(1000px)");
}









